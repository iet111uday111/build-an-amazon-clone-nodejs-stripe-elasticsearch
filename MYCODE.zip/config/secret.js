module.exports = {
    database: 'mongodb://localhost:27017/ecommerce',
    port: 3000,
    secretKey: 'Uday@!#$@!%*^'
}