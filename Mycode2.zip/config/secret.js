module.exports = {
  database: 'mongodb://localhost:27017/ecommerce',
  port: 3000,
  secretKey: 'Uday@!#$@!%*^',
  stripePublishablekey: 'pk_test_jF4vEaPAZyxQDlf1vVQeOS2s',
  stripeSecretkey: 'sk_test_U2lPdCtj3aDcRssWbTrSPnhq'
}